package com.theNumbers.openGLES;

import com.theNumbers.game.AssetsManager;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.View;

public class OpenGLESSurfaceView extends GLSurfaceView {
	
	private OpenGLESRenderer renderer;
	
	public OpenGLESSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        renderer = new OpenGLESRenderer(context);
        setRenderer(renderer);
    }
	
	@Override
    public boolean onTouchEvent(MotionEvent event) {

        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                
                break;
            case MotionEvent.ACTION_MOVE:
                
                break;
            case MotionEvent.ACTION_UP:
                AssetsManager.mIsTouched = true;
                AssetsManager.mEventPositionX = event.getX();
                AssetsManager.mEventPositionY = event.getY();
                requestRender();
                break;
        }
        return true;
    }
	
}
