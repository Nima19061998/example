package com.theNumbers.openGLES;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import com.theNumbers.game.AssetsManager;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

public class OpenGLESRenderer implements GLSurfaceView.Renderer {
	
	private final Context mActivityContext;
	private final float[] mMVPMatrix = new float[16];
	private final float[] mProjMatrix = new float[16];
	private final float[] mVMatrix = new float[16];
	private float[] mRotationMatrix = new float[16];
	private boolean onCreate = true;
	public static float[] mStaticMVPMatrix = new float[16];
	public volatile float mAngle;
	
	public OpenGLESRenderer(final Context context) {
		mActivityContext = context;
	}

    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        GLES20.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
     	GLES20.glEnable(GLES20.GL_BLEND);
     	GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
     	AssetsManager.loadAssets(mActivityContext);
    }

    public void onDrawFrame(GL10 unused) {
        GLES20.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
        Matrix.setLookAtM(mVMatrix, 0, 0, 0, -3, 0f, 0f, 0f, 0f, 1.0f, 0.0f);
        Matrix.multiplyMM(mMVPMatrix, 0, mProjMatrix, 0, mVMatrix, 0);
        Matrix.setRotateM(mRotationMatrix, 0, mAngle, 0, 0, -1.0f);
        Matrix.multiplyMM(mMVPMatrix, 0, mRotationMatrix, 0, mMVPMatrix, 0);
        AssetsManager.equalizeMatrices(mMVPMatrix);
        if (onCreate) {
        	onCreate = false;
        	AssetsManager.load(mActivityContext);
        	AssetsManager.save(mActivityContext);
        	AssetsManager.createGUI();
        	AssetsManager.updateLines();
        	AssetsManager.mDoesFileExist = false;
        }
        AssetsManager.updateTime();
        AssetsManager.drawGUI();
        AssetsManager.drawRooms(mActivityContext);
        AssetsManager.mIsTouched = false;
    }

    public void onSurfaceChanged(GL10 unused, int width, int height) {
    	float aspectRatio = (float) width / height;
        GLES20.glViewport(0, 0, width, height);
        Matrix.frustumM(mProjMatrix, 0, -aspectRatio * 960, aspectRatio * 960, -960, 960, 3, 7);
        AssetsManager.updateLines();
    }

    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
	
}
