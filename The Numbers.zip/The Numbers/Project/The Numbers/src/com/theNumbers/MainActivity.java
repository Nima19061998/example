package com.theNumbers;

import com.theNumbers.openGLES.OpenGLESSurfaceView;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.WindowManager.LayoutParams;

public class MainActivity extends Activity {

	private GLSurfaceView glView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        glView = new OpenGLESSurfaceView(this);
        //glView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        getWindow().setFlags(LayoutParams.FLAG_SECURE, LayoutParams.FLAG_SECURE);
        setContentView(glView);
    }
    
    @Override
    protected void onStop(){
       super.onStop();
       MainActivity.this.finish();
       System.exit(0);
    }
    
    @Override
    protected void onPause(){
       super.onPause();
       MainActivity.this.finish();
       System.exit(0);
    }

}