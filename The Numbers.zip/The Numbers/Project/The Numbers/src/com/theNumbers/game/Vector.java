package com.theNumbers.game;

public class Vector {
	
	public float mComponentX = 0;
	public float mComponentY = 0;
	
	public Vector() {}
	
	public Vector(float components) {
		mComponentX = mComponentY = components;
	}
	
	public Vector(float componentX, float componentY) {
		mComponentX = componentX;
		mComponentY = componentY;
	}
	
}
