package com.theNumbers.game;

import java.util.Random;

public class Grid {
	
	private byte[][] mGrid;
	private SpriteRing[] mSpriteRings;
	private static float MINIMUM_ASPECT_RATIO = .95f;
	
	public Grid(byte number, short width, short height) {
		grid(number, width, height);
	}
	
	public Grid(byte number) {
		grid(number, (short) 1080, (short) 1920);
	}
	
	public Grid() {
		grid((byte) 3, (short) 1080, (short) 1920);
	}
	
	public void setStatus(byte status, byte index) {
		mSpriteRings[index].mStatus = status;
	}
	
	public byte getLength() {
		return (byte) mSpriteRings.length;
	}
	
	public void create(byte number, short width, short height) {
		mGrid = randomGrid(number, width, height);
		mSpriteRings = new SpriteRing[number];
		update(width, height);
	}
	
	public void update(short width, short height) {
		float size = (float) height / mGrid[0].length < (float) width / mGrid.length ? (float) height / mGrid[0].length : (float) width / mGrid.length;
		float scale = size / Texture.Ring.mWidth;
		for (byte i = 0, counter = 0; i < mGrid.length; i++)
			for (byte j = 0; j < mGrid[0].length; j++)
				if (mGrid[i][j] != 0)
					mSpriteRings[counter++] = new SpriteRing(mGrid[i][j], (i * 2 - mGrid.length + 1) * size / 2, (j * (-2) + mGrid[0].length - 1) * size / 2 - 87.5f, scale * .975f);
	}
	
	public byte[] onTouch() {
		byte[] result = {0, 0};
		for (byte i = 0; i < mSpriteRings.length; i++)
			if (mSpriteRings[i].onTouch() != 0) {
				result[0] = mSpriteRings[i].onTouch();
				result[1] = i;
			}
		return result;
	}
	
	public void draw() {
		for (byte i = 0; i < mSpriteRings.length; i++)
			mSpriteRings[i].draw();
	}
	
	private void grid(byte number, short width, short height) {
		create(number, width, height);
	}
	
	private byte[][] randomGrid(byte number, short width, short height) {
		byte[][] result;
		byte[] gridSize = selectGrid(number, width, height);
		short size = (short) (gridSize[0] * gridSize[1]);
		result = new byte[gridSize[0]][gridSize[1]];
		for (byte i = 0; i < result.length; i++)
			for (byte j = 0; j < result[0].length; j++)
				result[i][j] = 0;
		for (byte i = 1; i <= number; i++)
			while (true)
			{
				Random random = new Random();
				byte randomNumber = (byte) random.nextInt(size);
				if (result[randomNumber / result[0].length][randomNumber % result[0].length] != -1)
				{
					result[randomNumber / result[0].length][randomNumber % result[0].length] = -1;
					break;
				}
			}
		for (byte i = 0; i < result.length; i++)
			for (byte j = 0; j < result[0].length; j++)
				if (result[i][j] == -1)
					while (true)
					{
						Random random = new Random();
						byte randomNumber = (byte) (random.nextInt(number) + 1);
						boolean existence = false;
						for (byte m = 0; m < result.length && !existence; m++)
							for (byte n = 0; n < result[0].length && !existence; n++)
								if (result[m][n] == randomNumber)
									existence = true;
						if (!existence)
						{
							result[i][j] = randomNumber;
							break;
						}
					}
		return result;
	}
	
	private float[] areaAspectRatios(byte number, short width, short height) {
		float[] result;
		byte[] divisibility = numberDivisibility(number);
		result = new float[divisibility.length];
		for (byte i = 0; i < result.length; i++)
			result[i] = ((float) height / divisibility[result.length - i - 1]) / ((float) width / divisibility[i]);
		for (byte i = 0; i < result.length; i++)
			if (result[i] > 1)
				result[i] = 1 / result[i];
		return result;
	}
	
	private byte[] selectGrid(byte number, short width, short height) {
		float[] aspectRatios;
		byte[] result = new byte[2];
		byte[] divisibility;
		float maximum = 0;
		int index = 0;
		for (int i = 0;true ; i++)
		{
			aspectRatios = areaAspectRatios((byte) (number + i), width, height);
			divisibility = numberDivisibility((byte) (number + i));
			for (int j = 0; j < aspectRatios.length; j++)
				if (aspectRatios[j] > maximum)
				{
					maximum = aspectRatios[j];
					index = j;
				}
			if (maximum >= MINIMUM_ASPECT_RATIO)
			{
				result[0] = divisibility[index];
				result[1] = divisibility[divisibility.length - index - 1];
				break;
			}
		}
		return result;
	}
	
	private byte[] numberDivisibility(byte number) {
		byte[] result;
		byte counter = 0;
		for (byte i = 1; i <= number; i++)
			if (number % i == 0)
				counter++;
		result = new byte[counter];
		counter = 0;
		for (byte i = 1; i <= number; i++)
			if (number % i == 0)
				result[counter++] = i;
		return result;
	}
	
}
