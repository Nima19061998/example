package com.theNumbers.game.gui;

import com.theNumbers.game.AssetsManager;
import com.theNumbers.game.Field;
import com.theNumbers.game.Texture;
import com.theNumbers.game.Vector;

public class FieldUI extends GUI {

	private Field mField;
	
	public FieldUI(Texture texture, int number, float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float spriteScale, float textScale, float scale) {
		super(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY, scale);
		fieldUI(texture, number, spriteScale, textScale);
	}
	
	public FieldUI(Texture texture, int number, float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float spriteScale, float textScale) {
		super(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY, 1);
		fieldUI(texture, number, spriteScale, textScale);
	}
	
	public FieldUI(Texture texture, int number, float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY) {
		super(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY);
		fieldUI(texture, number, 1, 1);
	}
	
	public FieldUI(Texture texture, int number, float percentalPositionX, float percentalPositionY) {
		super(percentalPositionX, percentalPositionY);
		fieldUI(texture, number, 1, 1);
	}
	
	public FieldUI(Texture texture, int number) {
		super();
		fieldUI(texture, number, 1, 1);
	}
	
	public FieldUI() {
		super();
		fieldUI(Texture.None, 0, 1, 1);
	}
	
	public void setTexture(Texture texture) {
		mField.setTexture(texture);
	}
	
	public void setNumber(int number) {
		mField.setNumber(number);
	}
	
	public void setTransform(float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float scale) {
		mPercentalPosition = new Vector(percentalPositionX, percentalPositionY);
		mPixelarPosition = new Vector(pixelarPositionX, pixelarPositionY);
		mScale = scale;
		updateTransform();
	}
	
	public void setPercentalPosition(float percentalPositionX, float percentalPositionY) {
		mPercentalPosition = new Vector(percentalPositionX, percentalPositionY);
		updateTransform();
	}
	
	public void setPixelarPosition(float pixelarPositionX, float pixelarPositionY) {
		mPixelarPosition = new Vector(pixelarPositionX, pixelarPositionY);
		updateTransform();
	}
	
	public void setScale(float scale) {
		mScale = scale;
		updateTransform();
	}
	
	public void draw() {
		mField.draw();
	}
	
	private void fieldUI(Texture texture, int number, float spriteScale, float textScale) {
		mField = new Field(texture, number, 0, 0, spriteScale, textScale);
		updateTransform();
	}
	
	private void updateTransform() {
		float aspectRatio = (float) AssetsManager.getScreenHeight() / AssetsManager.getScreenWidth();
		float positionX, positionY, spriteScale, textScale;
		if (aspectRatio > REFERENCE_ASPECT_RATIO) {
			float scale = REFERENCE_ASPECT_RATIO / aspectRatio;
			spriteScale = mField.getSpriteScale() * mScale * scale;
			textScale = mField.getTextScale() * mScale * scale;
			positionX = mPercentalPosition.mComponentX * AssetsManager.getViewWidth() / 2 + mPixelarPosition.mComponentX * scale;
			positionY = mPercentalPosition.mComponentY * AssetsManager.getViewHeight() / 2 + mPixelarPosition.mComponentY * scale;
		} else {
			spriteScale = mField.getSpriteScale() * mScale;
			textScale = mField.getTextScale() * mScale;
			positionX = mPercentalPosition.mComponentX * AssetsManager.getViewWidth() / 2 + mPixelarPosition.mComponentX;
			positionY = mPercentalPosition.mComponentY * AssetsManager.getViewHeight() / 2 + mPixelarPosition.mComponentY;
		}
		mField.setTransform(positionX, positionY, spriteScale, textScale);
	}
	
}
