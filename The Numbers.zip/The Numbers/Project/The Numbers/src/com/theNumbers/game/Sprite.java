package com.theNumbers.game;

import android.opengl.Matrix;
import android.view.MotionEvent;

import com.theNumbers.game.Texture;

public class Sprite {
	
	private Texture mTexture;
	private float[] mModelMatrix;
	private Vector mPosition;
	private Vector mScale;
	
	public Sprite(Texture texture, float positionX, float positionY, float scaleX, float scaleY) {
		sprite(texture, positionX, positionY, scaleX, scaleY);
	}
	
	public Sprite(Texture texture, float positionX, float positionY) {
		sprite(texture, positionX, positionY, 1, 1);
	}
	
	public Sprite(Texture texture) {
		sprite(texture, 0, 0, 1, 1);
	}
	
	public Sprite() {
		sprite(Texture.None, 0, 0, 1, 1);
	}
	
	public void setTexture(Texture texture) {
		mTexture = texture;
	}
	
	public void setTransform(float positionX, float positionY, float scaleX, float scaleY) {
		mPosition = new Vector(positionX, positionY);
		mScale = new Vector(scaleX, scaleY);
		updateTransform();
	}
	
	public void setPosition(float positionX, float positionY) {
		mPosition = new Vector(positionX, positionY);
		updateTransform();
	}
	
	public void setScale(float scaleX, float scaleY) {
		mScale = new Vector(scaleX, scaleY);
		updateTransform();
	}
	
	public Texture getTexture() {
		return mTexture;
	}
	
	public Vector getPosition() {
		return mPosition;
	}
	
	public Vector getScale() {
		return mScale;
	}
	
	public boolean onTouch() {
		if (AssetsManager.mIsTouched) {
			float width = mTexture.mWidth * mScale.mComponentX / 2f;
			float height = mTexture.mHeight * mScale.mComponentY / 2f;
			if (AssetsManager.getToucherPositionX() < mPosition.mComponentX + width && AssetsManager.getToucherPositionX() > mPosition.mComponentX - width && AssetsManager.getToucherPositionY() < mPosition.mComponentY + height && AssetsManager.getToucherPositionY() > mPosition.mComponentY - height)
				return true;
		}
		return false;
	}
	
	public void draw() {
		float[] scratch = new float[16];
		Matrix.multiplyMM(scratch, 0, AssetsManager.mMVPMatrix, 0, mModelMatrix, 0);
		AssetsManager.mTextures[mTexture.mID].draw(scratch);
	}
	
	private void sprite(Texture texture, float positionX, float positionY, float scaleX, float scaleY) {
		mModelMatrix = new float[16];
		mTexture = texture;
		mPosition = new Vector(positionX, positionY);
		mScale = new Vector(scaleX, scaleY);
		updateTransform();
	}
	
	private void updateTransform() {
		//float[] scratch = new float[16];
		Matrix.setIdentityM(mModelMatrix, 0);
		Matrix.translateM(mModelMatrix, 0, -mPosition.mComponentX, mPosition.mComponentY, 0);
		Matrix.scaleM(mModelMatrix, 0, mScale.mComponentX, mScale.mComponentY, 1);
		//Matrix.multiplyMM(scratch, 0, AssetsManager.mMVPMatrix, 0, mModelMatrix, 0);
		//for (int i = 0; i < 16; i++)
		//	mModelMatrix[i] = scratch[i];
	}
	
}
