package com.theNumbers.game;

public class SpriteRing {
	
	public byte mStatus;
	private Text mText;
	private Sprite mSpriteRing;
	private Sprite mSpriteQuestionMark;
	private Sprite mSpriteXMark;
	private byte mNumber = 1;
	
	public SpriteRing(byte number, float positionX, float positionY, float scale, byte status) {
		spriteRing(number, positionX, positionY, scale, status);
	}
	
	public SpriteRing(byte number, float positionX, float positionY, float scale) {
		spriteRing(number, positionX, positionY, scale, (byte) 0);
	}
	
	public SpriteRing(byte number, float positionX, float positionY) {
		spriteRing(number, positionX, positionY, 1, (byte) 0);
	}
	
	public SpriteRing(byte number) {
		spriteRing(number, 0, 0, 1, (byte) 0);
	}
	
	public SpriteRing() {
		spriteRing((byte) 1, 0, 0, 1, (byte) 0);
	}
	
	public void setNumber(byte number) {
		mText.setString(String.valueOf((int) number));
	}
	
	public void setTransform(float positionX, float positionY, float scale) {
		mText.setTransform(positionX, positionY, scale);
		mSpriteRing.setTransform(positionX, positionY, scale, scale);
		mSpriteQuestionMark.setTransform(positionX, positionY, scale, scale);
		mSpriteXMark.setTransform(positionX, positionY, scale, scale);
	}

	public void setPosition(float positionX, float positionY) {
		mText.setPosition(positionX, positionY);
		mSpriteRing.setPosition(positionX, positionY);
		mSpriteQuestionMark.setPosition(positionX, positionY);
		mSpriteXMark.setPosition(positionX, positionY);
	}
	
	public void setScale(float scale) {
		mText.setScale(scale);
		mSpriteRing.setScale(scale, scale);
		mSpriteQuestionMark.setScale(scale, scale);
		mSpriteXMark.setScale(scale, scale);
	}
	
	public byte getNumber() {
		return mNumber;
	}
	
	public Vector getPosition() {
		return mSpriteRing.getPosition();
	}
	
	public float getScale() {
		return mSpriteRing.getScale().mComponentX;
	}
	
	public byte onTouch() {
		if (mStatus == 1)
			if (mSpriteRing.onTouch())
				return mNumber;
		return 0;
	}
	
	public void draw() {
		mSpriteRing.draw();
		switch (mStatus) {
		case 0:
			mText.draw();
			break;
		case 1:
			mSpriteQuestionMark.draw();
			break;
		case 2:
			mSpriteXMark.draw();
			break;
		}
	}
	
	private void spriteRing(byte number, float positionX, float positionY, float scale, byte status) {
		mNumber = number;
		mText = new Text(String.valueOf((int) number), positionX, positionY, scale);
		mSpriteRing = new Sprite(Texture.Ring, positionX, positionY, scale, scale);
		mSpriteQuestionMark = new Sprite(Texture.QuestionMark, positionX, positionY, scale, scale);
		mSpriteXMark = new Sprite(Texture.XMark, positionX, positionY, scale, scale);
		mStatus = status;
	}
	
}
