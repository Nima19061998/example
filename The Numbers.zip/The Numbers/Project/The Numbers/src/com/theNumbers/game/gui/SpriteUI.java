package com.theNumbers.game.gui;

import com.theNumbers.game.AssetsManager;
import com.theNumbers.game.Sprite;
import com.theNumbers.game.Texture;
import com.theNumbers.game.Vector;

public class SpriteUI extends GUI {

	private Sprite mSprite;
	
	public SpriteUI(Texture texture, float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float scale) {
		super(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY, scale);
		spriteUI(texture);
	}
	
	public SpriteUI(Texture texture, float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY) {
		super(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY);
		spriteUI(texture);
	}
	
	public SpriteUI(Texture texture, float percentalPositionX, float percentalPositionY) {
		super(percentalPositionX, percentalPositionY);
		spriteUI(texture);
	}
	
	public SpriteUI(Texture texture) {
		super();
		spriteUI(texture);
	}
	
	public SpriteUI() {
		super();
		spriteUI(Texture.None);
	}
	
	public void setTexture(Texture texture) {
		mSprite.setTexture(texture);
		updateTransform();
	}
	
	public void setTransform(float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float scale) {
		mPercentalPosition = new Vector(percentalPositionX, percentalPositionY);
		mPixelarPosition = new Vector(pixelarPositionX, pixelarPositionY);
		mScale = scale;
		updateTransform();
	}
	
	public void setPercentalPosition(float positionX, float positionY) {
		mPercentalPosition = new Vector(positionX, positionY);
		updateTransform();
	}
	
	public void setPixelarPosition(float positionX, float positionY) {
		mPixelarPosition = new Vector(positionX, positionY);
		updateTransform();
	}
	
	public void setScale(float scale) {
		mScale = scale;
		updateTransform();
	}
	
	public boolean onTouch() {
		return mSprite.onTouch();
	}
	
	public void draw() {
		mSprite.draw();
	}
	
	private void spriteUI(Texture texture) {
		mSprite = new Sprite(texture);
		updateTransform();
	}
	
	private void updateTransform() {
		float aspectRatio = (float) AssetsManager.getScreenHeight() / AssetsManager.getScreenWidth();
		float positionX, positionY, spriteScale;
		if (aspectRatio > REFERENCE_ASPECT_RATIO) {
			float scale = REFERENCE_ASPECT_RATIO / aspectRatio;
			spriteScale = mScale * scale;
			positionX = mPercentalPosition.mComponentX * AssetsManager.getViewWidth() / 2 + mPixelarPosition.mComponentX * scale;
			positionY = mPercentalPosition.mComponentY * AssetsManager.getViewHeight() / 2 + mPixelarPosition.mComponentY * scale;
		} else {
			spriteScale = mScale;
			positionX = mPercentalPosition.mComponentX * AssetsManager.getViewWidth() / 2 + mPixelarPosition.mComponentX;
			positionY = mPercentalPosition.mComponentY * AssetsManager.getViewHeight() / 2 + mPixelarPosition.mComponentY;
		}
		mSprite.setTransform(positionX, positionY, spriteScale, spriteScale);
	}
	
}
