package com.theNumbers.game;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

import android.content.Context;
import android.content.res.Resources;

import com.theNumbers.R;
import com.theNumbers.game.gui.FieldUI;
import com.theNumbers.game.gui.GUI;
import com.theNumbers.game.gui.SpriteUI;
import com.theNumbers.game.gui.TextUI;
import com.theNumbers.openGLES.OpenGLESTexture;

public class AssetsManager {
	
	public static final OpenGLESTexture[] mTextures = new OpenGLESTexture[Texture.values().length];
	public static final long MAXIMUM_TOTAL_SCORE = 9223372036854775807l;
	public static final short MAXIMUM_LEVEL = (short) 30000;
	public static final short MAXIMUM_LIVE = (short) 30000;
	public static final byte MAXIMUM_SPRITE_RINGS = (byte) 84;
	public static final byte MAXIMUM_FREE_LIVE = (byte) 72;
	public static final byte ADD_LIVES = (byte) 50;
	public static float[] mMVPMatrix = new float[16];
	public static float mEventPositionX = 0;
	public static float mEventPositionY = 0;
	public static long mTotalScore = 0;
	public static int mHighScore = 0;
	public static int mScore = 0;
	public static short mLevel = 1;
	public static short mLive = 50;
	public static byte mFreeLive = 0;
	public static byte mRoom = 0;
	public static byte mCounter = (byte) 1;
	public static boolean mShowQuestionMark = true;
	public static boolean mWin = false;
	public static boolean mLoss = false;
	public static boolean mIsTouched = false;
	private static SpriteUI mSpriteUILiveBorder;
	private static SpriteUI mSpriteUIHeart;
	private static SpriteUI mSpriteUIFreeLive;
	private static SpriteUI mSpriteUIOf;
	private static SpriteUI mSpriteUIIn;
	private static SpriteUI mSpriteUIScoreBorder;
	private static SpriteUI mSpriteUIMedal;
	private static SpriteUI mSpriteUIButton;
	private static SpriteUI mSpriteUITapToPlay;
	private static SpriteUI mSpriteUINoLive;
	private static SpriteUI mSpriteUITotalScore;
	private static SpriteUI mSpriteUICongratulations;
	private static SpriteUI mSpriteUIYouWon;
	private static TextUI mTextUILive;
	private static TextUI mTextUIFreeLive;
	private static TextUI mTextUIMaximumFreeLive;
	private static TextUI mTextUITime;
	private static TextUI mTextUIScore;
	private static TextUI mTextUITotalScore;
	private static FieldUI mFieldUIHighScore;
	private static Sprite[] mSpriteLines;
	private static Field mFieldLevel;
	private static Time mTime = new Time();
	public static Timer mTimer;
	private static Grid mGrid;
	private static boolean[] mData = new boolean[360];
	public static boolean mDoesFileExist = false;
	
	public static int getScreenWidth() {
	    return Resources.getSystem().getDisplayMetrics().widthPixels;
	}

	public static int getScreenHeight() {
	    return Resources.getSystem().getDisplayMetrics().heightPixels;
	}
	
	public static float getViewWidth() {
		return (float) getScreenWidth() / getScreenHeight() * 1920f;
	}
	
	public static float getViewHeight() {
		return 1920f;
	}
	
	public static float getToucherPositionX() {
		return mEventPositionX * getViewWidth() / getScreenWidth() - getViewWidth() / 2;
	}
	
	public static float getToucherPositionY() {
		return -mEventPositionY * getViewHeight() / getScreenHeight() + getViewHeight() / 2;
	}
	
	public static void save(Context context) {
		if (!mDoesFileExist) {
			saveData();
			saveFile(context);
		}
	}
	
	public static void load(Context context) {
		loadFile(context);
		if (mDoesFileExist)
			loadData();
	}
	
	public static void saveFile(Context context) {
		byte[] data = new byte[360];
		for (short i = 0; i < 360; i++)
			data[i] = (byte) (mData[i] ? 1 : 0);
		try {
	    FileOutputStream outputStream = context.openFileOutput("Data.bin", Context.MODE_PRIVATE);
	    outputStream.write(data, 0, 360);
	    outputStream.close();
		} catch (IOException e) {
			
		}
	}
	
	public static void loadFile(Context context) {
		try {
	    FileInputStream inputStream = context.openFileInput("Data.bin");
	    byte[] data = new byte[360];
	    inputStream.read(data, 0, 360);
	    for (short i = 0; i < 360; i++)
	        mData[i] = data[i] == 1 ? true : false;
	    inputStream.close();
	    mDoesFileExist = true;
		} catch (IOException e) {
			
		}
	}
	
	public static void saveData() {
		Random random = new Random();
		short index = 0;
		byte randomNumber = (byte) random.nextInt(128);
		boolean[] result = byteToBooleans(randomNumber);
		mData = new boolean[360];
		for (short i = index; i < index + 8; i++)
			mData[i] = result[i - index];
		index += 8;
		result = longToBooleans(mTime.getTime());
		for (short i = index; i < index + 64; i++)
			mData[i] = result[i - index];
		index += 64;
		result = longToBooleans(mTotalScore);
		for (short i = index; i < index + 64; i++)
			mData[i] = result[i - index];
		index += 64;
		result = integerToBooleans(mHighScore);
		for (short i = index; i < index + 32; i++)
			mData[i] = result[i - index];
		index += 32;
		result = shortToBooleans(mLive);
		for (short i = index; i < index + 16; i++)
			mData[i] = result[i - index];
		index += 16;
		for (short i = 0; i < index - 8; i++)
			mData[index + i] = !mData[i + 8];
		for (short i = 8; i < 360; i++) {
			boolean temporary = mData[i];
			mData[i] = mData[(i + randomNumber - 8) % 352 + 8];
			mData[(i + randomNumber - 8) % 352 + 8] = temporary;
		}
	}
	
	public static void loadData() {
		byte randomNumber;
		boolean[] dataBooleans = new boolean[8];
		boolean wrong = false;
		for (byte i = 0; i < 8; i++)
			dataBooleans[i] = mData[i];
		randomNumber = booleansToByte(dataBooleans);
		for (short i = 359; i >= 8; i--) {
			boolean temporary = mData[i];
			mData[i] = mData[(i + randomNumber - 8) % 352 + 8];
			mData[(i + randomNumber - 8) % 352 + 8] = temporary;
		}
		for (short i = 8; i < 184; i++)
			if (mData[i] == mData[i + 176]) {
				wrong = true;
				break;
			}
		if (wrong) {
			mTime = new Time();
			mTotalScore = 0;
			mHighScore = 0;
			mLive = 50;
		} else {
			short index = 8;
			dataBooleans = new boolean[64];
			for (short i = index; i < index + 64; i++)
				dataBooleans[i - index] = mData[i];
			index += 64;
			mTime.setTime(booleansToLong(dataBooleans));
			dataBooleans = new boolean[64];
			for (short i = index; i < index + 64; i++)
				dataBooleans[i - index] = mData[i];
			index += 64;
			mTotalScore = booleansToLong(dataBooleans);
			dataBooleans = new boolean[32];
			for (short i = index; i < index + 32; i++)
				dataBooleans[i - index] = mData[i];
			index += 32;
			mHighScore = booleansToInteger(dataBooleans);
			dataBooleans = new boolean[16];
			for (short i = index; i < index + 16; i++)
				dataBooleans[i - index] = mData[i];
			index += 16;
			mLive = booleansToShort(dataBooleans);
		}
	}
	
	private static boolean[] longToBooleans(long number) {
		boolean[] result = new boolean[64];
		for (byte i = 63; number > 0; number /= 2)
			result[i--] = number % 2 == 0 ? false : true;
		return result;
	}
	
	private static boolean[] integerToBooleans(int number) {
		boolean[] result = new boolean[32];
		for (byte i = 31; number > 0; number /= 2)
			result[i--] = number % 2 == 0 ? false : true;
		return result;
	}
	
	private static boolean[] shortToBooleans(short number) {
		boolean[] result = new boolean[16];
		for (byte i = 15; number > 0; number /= 2)
			result[i--] = number % 2 == 0 ? false : true;
		return result;
	}
	
	private static boolean[] byteToBooleans(byte number) {
		boolean[] result = new boolean[8];
		for (byte i = 7; number > 0; number /= 2)
			result[i--] = number % 2 == 0 ? false : true;
		return result;
	}
	
	private static long booleansToLong(boolean[] number) {
		long result = 0;
		for (byte i = 63; i > 0; i--)
			if (number[i])
				result += power((byte) (63 - i));
		return result;
	}
	
	private static int booleansToInteger(boolean[] number) {
		int result = 0;
		for (byte i = 31; i > 0; i--)
			if (number[i])
				result += power((byte) (31 - i));
		return result;
	}
	
	private static short booleansToShort(boolean[] number) {
		short result = 0;
		for (byte i = 15; i > 0; i--)
			if (number[i])
				result += power((byte) (15 - i));
		return result;
	}
	
	private static byte booleansToByte(boolean[] number) {
		byte result = 0;
		for (byte i = 7; i > 0; i--)
			if (number[i])
				result += power((byte) (7 - i));
		return result;
	}
	
	private static long power(byte number) {
		long result = 1;
		for (; number > 0; number--)
			result *= 2;
		return result;
	}
	
	
	public static void createGUI() {
		mTimer = new Timer();
		mGrid = new Grid(countSpriteRings(), (short) getViewWidth(), (short) (getViewHeight() - 175));
		mSpriteUILiveBorder =  new SpriteUI(Texture.Border, -1, 1, 240, -75);
		mSpriteUIHeart =  new SpriteUI(Texture.Heart, -1, 1, 75.5f, -75);
		mSpriteUIFreeLive = new SpriteUI(Texture.FreeLive, -1, 1, 102.891f, -154.833f);
		mSpriteUIOf = new SpriteUI(Texture.Of, -1, 1, 254.594f, -155.176f);
		mSpriteUIIn = new SpriteUI(Texture.In, -1, 1, 348.523f, -156.028f);
		mSpriteUIScoreBorder =  new SpriteUI(Texture.Border, 1, 1, -240, -75);
		mSpriteUIMedal =  new SpriteUI(Texture.Medal, 1, 1, -404.5f, -77.914f);
		mSpriteUIButton =  new SpriteUI(Texture.Button, -1, 1, 540, -75);
		mSpriteUITapToPlay = new SpriteUI(Texture.TapToPlay);
		mSpriteUINoLive = new SpriteUI(Texture.NoLive, 0, 0, 0, -110);
		mSpriteUITotalScore = new SpriteUI(Texture.TotalScore, 0, 0, 0, -435);
		mSpriteUICongratulations = new SpriteUI(Texture.Congratulations);
		mSpriteUIYouWon = new SpriteUI(Texture.YouWon, 0, 0, 0, -50);
		mTextUILive = new TextUI(String.valueOf((int) mLive), -1, 1, 295, -75, .25f);
		mTextUIFreeLive = new TextUI(String.valueOf((int) mFreeLive), -1, 1, 204.664f, -156.051f, .125f);
		mTextUIMaximumFreeLive = new TextUI(String.valueOf((int) MAXIMUM_FREE_LIVE), -1, 1, 302.922f, -156.028f, .125f);
		mTextUITime = new TextUI(mTime.showTime(), -1, 1, 410.023f, -156.051f, .125f);
		mTextUIScore = new TextUI(String.valueOf(mScore), 1, 1, -185, -75, .25f);
		mTextUITotalScore = new TextUI(String.valueOf(mTotalScore), 0, 0, 0, -525, .25f);
		mFieldUIHighScore = new FieldUI(Texture.HighScore, mHighScore, 1, 1, -240, -157.5f, 1, .125f);
		mFieldLevel = new Field(Texture.Level, mLevel, 0, 0, 1, 0.5416667f);
	}
	
	public static void updateLines() {
		float distance, space;
		byte count;
		if (getViewHeight() / getViewWidth() > GUI.REFERENCE_ASPECT_RATIO) {
			count = (byte) (18360 / getViewWidth());
			space = getViewWidth() * 2 / 27;
		} else {
			count = (byte) 18;
			space = 80;
		}
		distance = 1530.f / count;
		mSpriteLines = new Sprite[count + 1];
		for (byte i = 0; i < mSpriteLines.length; i++)
			mSpriteLines[i] = new Sprite(Texture.Line, 0, i * -distance + 710.f, getViewWidth() - space, 1);
	}
	
	public static void updateGrid() {
		mGrid.update((short) getViewWidth(), (short) (getViewHeight() - 175));
	}
	
	public static void updateTime() {
		mTextUITime.setString(mTime.showTime());
		if (mFreeLive != mTime.getCounter()) {
			mFreeLive = mTime.getCounter();
			mTextUIFreeLive.setString(String.valueOf((byte) mFreeLive));
		}
	}
	
	public static void addLives(Context context) {
		if (mLive + ADD_LIVES < MAXIMUM_LIVE)
			mLive += ADD_LIVES;
		save(context);
	}
	
	public static void loseLive(Context context) {
		if (mFreeLive > 0)
			mTime.loseCounter();
		else if (mLive > 0)
			mTextUILive.setString(String.valueOf((int) (--mLive)));
		save(context);
	}
	
	public static void addScore(Context context) {
		mScore++;
		mTotalScore++;
		if (mScore > mHighScore)
		{
			mHighScore = mScore;
			mFieldUIHighScore.setNumber(mHighScore);
		}
		mTextUIScore.setString(String.valueOf(mScore));
		mTextUITotalScore.setString(String.valueOf(mTotalScore));
		save(context);
	}
	
	public static void levelUp() {
		if (mLevel < MAXIMUM_LEVEL)
			mLevel++;
		mGrid.create(countSpriteRings(), (short) getViewWidth(), (short) (getViewHeight() - 175));
	}
	
	public static void levelDown() {
		if (mLevel > 1)
			mLevel--;
		mGrid.create(countSpriteRings(), (short) getViewWidth(), (short) (getViewHeight() - 175));
	}
	
	public static void drawMenu() {
		mSpriteUITapToPlay.draw();
		mSpriteUITotalScore.draw();
		mTextUITotalScore.draw();
		if (mFreeLive == 0 && mLive == 0)
			mSpriteUINoLive.draw();
	}
	
	public static void drawWin() {
		mSpriteUICongratulations.draw();
		mSpriteUIYouWon.draw();
	}
	
	public static void drawRooms(Context context) {
		switch (mRoom)
		{
		case 0:
			drawMenu();
			if (mIsTouched)
				if (mLive != 0 || mFreeLive != 0)
				{
					mRoom = 1;
					loseLive(context);
					mTimer.restart();
				}
			break;
		case 1:
			if (mTimer.getTimer() <= 1500 && !mWin && !mLoss)
			{
				mFieldLevel.setNumber(mLevel);
				mFieldLevel.draw();
			}
			else if (mTimer.getTimer() <= 4500 && !mWin && !mLoss)
			{
				mGrid.draw();
			}
			else if (!mWin && !mLoss)
			{
				byte[] touch = mGrid.onTouch();
				if (mShowQuestionMark)
				{
					mShowQuestionMark = false;
					for (byte i = 0; i < mGrid.getLength(); i++)
						mGrid.setStatus((byte) 1, i);
				}
				if (touch[0] != 0) {
					if (touch[0] == mCounter)
					{
						if (mCounter == mLevel + 2) {
							mWin = true;
							mTimer.restart();
						}
						mCounter++;
						addScore(context);
						mGrid.setStatus((byte) 0, touch[1]);
					}
					else
					{
						mLoss = true;
						mGrid.setStatus((byte) 2, touch[1]);
						mTimer.restart();
						for (byte i = 0; i < mGrid.getLength(); i++)
							if (i != touch[1])
								mGrid.setStatus((byte) 0, i);
					}
				}
				mGrid.draw();
			}
			if (mTimer.getTimer() >= 1500) {
			if (mWin)
			{
				mWin = false;
				mShowQuestionMark = true;
				if (mLevel == MAXIMUM_LEVEL)
				{
					mRoom = 2;
					mScore = 0;
					mLevel = 1;
				}
				mCounter = 1;
				levelUp();
				mTimer.restart();
			}
			else if (mLoss)
			{
				mLoss = false;
				mShowQuestionMark = true;
				if (mLive != 0 || mFreeLive != 0)
					loseLive(context);
				else
				{
					mRoom = 0;
					mScore = 0;
					mLevel = 1;
				}
				levelDown();
				mScore -= (int) (mScore - mCounter - countSpriteRings() + 1) < 0 ? 0 : mCounter + countSpriteRings() - 1;
				mCounter = 1;
				mTextUIScore.setString(String.valueOf(mScore));
				mTimer.restart();
			}
			}
			else if (mWin || mLoss)
				mGrid.draw();
			break;
		case 2:
			if (mIsTouched)
				mRoom = 0;
			drawWin();
		}
	}
	
	public static byte countSpriteRings() {
		return (byte) (mLevel + 2 > MAXIMUM_SPRITE_RINGS ? MAXIMUM_SPRITE_RINGS : mLevel + 2);
	}
	
	public static void drawGUI() {
		mSpriteUILiveBorder.draw();
		mSpriteUIHeart.draw();
		mSpriteUIFreeLive.draw();
		mSpriteUIOf.draw();
		mSpriteUIScoreBorder.draw();
		mSpriteUIMedal.draw();
		mSpriteUIButton.draw();
		mTextUILive.draw();
		mTextUIFreeLive.draw();
		mTextUIMaximumFreeLive.draw();
		mTextUIScore.draw();
		mFieldUIHighScore.draw();
		if (mFreeLive < MAXIMUM_FREE_LIVE) {
			mSpriteUIIn.draw();
			mTextUITime.draw();
		}
		for (byte i = 0; i < mSpriteLines.length; i++)
			mSpriteLines[i].draw();
	}
	
	public static void drawLines() {
		
	}
	
	public static void loadAssets(final Context context) {
		mTextures[Texture.Zero.mID] = new OpenGLESTexture(context, R.drawable.zero, Texture.Zero.mWidth, Texture.Zero.mHeight);
		mTextures[Texture.One.mID] = new OpenGLESTexture(context, R.drawable.one, Texture.One.mWidth, Texture.One.mHeight);
		mTextures[Texture.Two.mID] = new OpenGLESTexture(context, R.drawable.two, Texture.Two.mWidth, Texture.Two.mHeight);
		mTextures[Texture.Three.mID] = new OpenGLESTexture(context, R.drawable.three, Texture.Three.mWidth, Texture.Three.mHeight);
		mTextures[Texture.Four.mID] = new OpenGLESTexture(context, R.drawable.four, Texture.Four.mWidth, Texture.Four.mHeight);
		mTextures[Texture.Five.mID] = new OpenGLESTexture(context, R.drawable.five, Texture.Five.mWidth, Texture.Five.mHeight);
		mTextures[Texture.Six.mID] = new OpenGLESTexture(context, R.drawable.six, Texture.Six.mWidth, Texture.Six.mHeight);
		mTextures[Texture.Seven.mID] = new OpenGLESTexture(context, R.drawable.seven, Texture.Seven.mWidth, Texture.Seven.mHeight);
		mTextures[Texture.Eight.mID] = new OpenGLESTexture(context, R.drawable.eight, Texture.Eight.mWidth, Texture.Eight.mHeight);
		mTextures[Texture.Nine.mID] = new OpenGLESTexture(context, R.drawable.nine, Texture.Nine.mWidth, Texture.Nine.mHeight);
		mTextures[Texture.Colon.mID] = new OpenGLESTexture(context, R.drawable.colon, Texture.Colon.mWidth, Texture.Colon.mHeight);
		mTextures[Texture.QuestionMark.mID] = new OpenGLESTexture(context, R.drawable.question_mark, Texture.QuestionMark.mWidth, Texture.QuestionMark.mHeight);
		mTextures[Texture.XMark.mID] = new OpenGLESTexture(context, R.drawable.x_mark, Texture.XMark.mWidth, Texture.XMark.mHeight);
		mTextures[Texture.Border.mID] = new OpenGLESTexture(context, R.drawable.border, Texture.Border.mWidth, Texture.Border.mHeight);
		mTextures[Texture.Button.mID] = new OpenGLESTexture(context, R.drawable.button, Texture.Button.mWidth, Texture.Button.mHeight);
		mTextures[Texture.Heart.mID] = new OpenGLESTexture(context, R.drawable.heart, Texture.Heart.mWidth, Texture.Heart.mHeight);
		mTextures[Texture.Medal.mID] = new OpenGLESTexture(context, R.drawable.medal, Texture.Medal.mWidth, Texture.Medal.mHeight);
		mTextures[Texture.FreeLive.mID] = new OpenGLESTexture(context, R.drawable.free_live, Texture.FreeLive.mWidth, Texture.FreeLive.mHeight);
		mTextures[Texture.Of.mID] = new OpenGLESTexture(context, R.drawable.of, Texture.Of.mWidth, Texture.Of.mHeight);
		mTextures[Texture.In.mID] = new OpenGLESTexture(context, R.drawable.in, Texture.In.mWidth, Texture.In.mHeight);
		mTextures[Texture.HighScore.mID] = new OpenGLESTexture(context, R.drawable.high_score, Texture.HighScore.mWidth, Texture.HighScore.mHeight);
		mTextures[Texture.TapToPlay.mID] = new OpenGLESTexture(context, R.drawable.tap_to_play, Texture.TapToPlay.mWidth, Texture.TapToPlay.mHeight);
		mTextures[Texture.NoLive.mID] = new OpenGLESTexture(context, R.drawable.no_live, Texture.NoLive.mWidth, Texture.NoLive.mHeight);
		mTextures[Texture.TotalScore.mID] = new OpenGLESTexture(context, R.drawable.total_score, Texture.TotalScore.mWidth, Texture.TotalScore.mHeight);
		mTextures[Texture.Level.mID] = new OpenGLESTexture(context, R.drawable.level, Texture.Level.mWidth, Texture.Level.mHeight);
		mTextures[Texture.Congratulations.mID] = new OpenGLESTexture(context, R.drawable.congratulations, Texture.Congratulations.mWidth, Texture.Congratulations.mHeight);
		mTextures[Texture.YouWon.mID] = new OpenGLESTexture(context, R.drawable.you_won, Texture.YouWon.mWidth, Texture.YouWon.mHeight);
		mTextures[Texture.Ring.mID] = new OpenGLESTexture(context, R.drawable.ring, Texture.Ring.mWidth, Texture.Ring.mHeight);
		mTextures[Texture.Line.mID] = new OpenGLESTexture(context, R.drawable.line, Texture.Line.mWidth, Texture.Line.mHeight);
		mTextures[Texture.None.mID] = new OpenGLESTexture(context, R.drawable.none, Texture.None.mWidth, Texture.None.mHeight);
	}
	
	public static void equalizeMatrices(float[] mvpMatrix) {
		for (byte i = 0; i < 16; i++)
			mMVPMatrix[i] = mvpMatrix[i];
	}
	
}
