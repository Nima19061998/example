package com.theNumbers.game;

public class Font {
	
	public static final Texture[] mCharacters = {Texture.Zero, Texture.One, Texture.Two, Texture.Three, Texture.Four, Texture.Five, Texture.Six, Texture.Seven, Texture.Eight, Texture.Nine, Texture.Colon};
	
}
