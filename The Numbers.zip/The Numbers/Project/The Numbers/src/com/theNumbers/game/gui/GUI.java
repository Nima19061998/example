package com.theNumbers.game.gui;

import com.theNumbers.game.Vector;

public abstract class GUI {
	
	public static final float REFERENCE_ASPECT_RATIO = 1.7777778f;
	public Vector mPercentalPosition;
	public Vector mPixelarPosition;
	public float mScale;
	
	public GUI(float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float scale) {
		gui(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY, scale);
	}
	
	public GUI(float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY) {
		gui(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY, 1);
	}
	
	public GUI(float percentalPositionX, float percentalPositionY) {
		gui(percentalPositionX, percentalPositionY, 0, 0, 1);
	}
	
	public GUI() {
		gui(0, 0, 0, 0, 1);
	}
	
	private void gui(float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float scale) {
		mPercentalPosition = new Vector(percentalPositionX, percentalPositionY);
		mPixelarPosition = new Vector(pixelarPositionX, pixelarPositionY);
		mScale = scale;
	}
	
}
