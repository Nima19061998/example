package com.theNumbers.game;

public class Field {

	private Sprite mSprite;
	private Text mText;
	private Vector mPosition;
	
	public Field(Texture texture, int number, float positionX, float positionY, float spriteScale, float textScale) {
		field(texture, number, positionX, positionY, spriteScale, textScale);
	}
	
	public Field(Texture texture, int number, float positionX, float positionY) {
		field(texture, number, positionX, positionY, 1, 1);
	}
	
	public Field(Texture texture, int number) {
		field(texture, number, 0, 0, 1, 1);
	}
	
	public Field() {
		field(Texture.None, 0, 0, 0, 1, 1);
	}
	
	public void setTexture(Texture texture) {
		mSprite.setTexture(texture);
		updatePosition();
	}
	
	public void setNumber(int number) {
		mText.setString(String.valueOf(number));
		updatePosition();
	}
	
	public void setTransform(float positionX, float positionY, float spriteScale, float textScale) {
		mSprite.setScale(spriteScale, spriteScale);
		mText.setScale(textScale);
		mPosition = new Vector(positionX, positionY);
		updatePosition();
	}
	
	public void setPosition(float positionX, float positionY) {
		mPosition = new Vector(positionX, positionY);
		updatePosition();
	}
	
	public void setScale(float spriteScale, float textScale) {
		mSprite.setScale(spriteScale, spriteScale);
		mText.setScale(textScale);
		updatePosition();
	}
	
	public float getSpriteScale() {
		return mSprite.getScale().mComponentX;
	}
	
	public float getTextScale() {
		return mText.getScale();
	}
	
	public void draw() {
		mSprite.draw();
		mText.draw();
	}
	
	private void field(Texture texture, int number, float positionX, float positionY, float spriteScale, float textScale) {
		mSprite = new Sprite(texture, 0, 0, spriteScale, spriteScale);
		mText = new Text(String.valueOf(number), 0, 0, textScale);
		mPosition = new Vector(positionX, positionY);
		updatePosition();
	}
	
	private void updatePosition() {
		mSprite.setPosition(mPosition.mComponentX - mText.getScale() * mText.getString().length() * 87, mPosition.mComponentY);
		mText.setPosition(mPosition.mComponentX + mSprite.getTexture().mWidth * mSprite.getScale().mComponentX / 2, mPosition.mComponentY);
	}
	
}
