package com.theNumbers.game.gui;

import com.theNumbers.game.AssetsManager;
import com.theNumbers.game.Sprite;
import com.theNumbers.game.Text;
import com.theNumbers.game.Texture;
import com.theNumbers.game.Vector;

public class TextUI extends GUI {

	private Text mText;
	
	public TextUI(String string, float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float scale) {
		super(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY, scale);
		textUI(string);
	}
	
	public TextUI(String string, float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY) {
		super(percentalPositionX, percentalPositionY, pixelarPositionX, pixelarPositionY);
		textUI(string);
	}
	
	public TextUI(String string, float percentalPositionX, float percentalPositionY) {
		super(percentalPositionX, percentalPositionY);
		textUI(string);
	}
	
	public TextUI(String string) {
		super();
		textUI(string);
	}
	
	public TextUI() {
		super();
		textUI("0");
	}
	
	public void setString(String string) {
		mText.setString(string);
		updateTransform();
	}
	
	public void setTransform(float percentalPositionX, float percentalPositionY, float pixelarPositionX, float pixelarPositionY, float scale) {
		mPercentalPosition = new Vector(percentalPositionX, percentalPositionY);
		mPixelarPosition = new Vector(pixelarPositionX, pixelarPositionY);
		mScale = scale;
		updateTransform();
	}
	
	public void setPercentalPosition(float positionX, float positionY) {
		mPercentalPosition = new Vector(positionX, positionY);
		updateTransform();
	}
	
	public void setPixelarPosition(float positionX, float positionY) {
		mPixelarPosition = new Vector(positionX, positionY);
		updateTransform();
	}
	
	public void setScale(float scale) {
		mScale = scale;
		updateTransform();
	}
	
	public void draw() {
		mText.draw();
	}
	
	private void textUI(String string) {
		mText = new Text(string);
		updateTransform();
	}
	
	private void updateTransform() {
		float aspectRatio = (float) AssetsManager.getScreenHeight() / AssetsManager.getScreenWidth();
		float positionX, positionY, textScale;
		if (aspectRatio > REFERENCE_ASPECT_RATIO) {
			float scale = REFERENCE_ASPECT_RATIO / aspectRatio;
			textScale = mScale * scale;
			positionX = mPercentalPosition.mComponentX * AssetsManager.getViewWidth() / 2 + mPixelarPosition.mComponentX * scale;
			positionY = mPercentalPosition.mComponentY * AssetsManager.getViewHeight() / 2 + mPixelarPosition.mComponentY * scale;
		} else {
			textScale = mScale;
			positionX = mPercentalPosition.mComponentX * AssetsManager.getViewWidth() / 2 + mPixelarPosition.mComponentX;
			positionY = mPercentalPosition.mComponentY * AssetsManager.getViewHeight() / 2 + mPixelarPosition.mComponentY;
		}
		mText.setTransform(positionX, positionY, textScale);
	}
	
}
