package com.theNumbers.game;

import com.theNumbers.game.Sprite;

public class Text {
	
	private Sprite[] mCharacters;
	private String mString;
	private Vector mPosition;
	private float mScale;
	
	public Text(String string, float positionX, float positionY, float scale) {
		text(string, positionX, positionY, scale);
	}
	
	public Text(String string, float positionX, float positionY) {
		text(string, positionX, positionY, 1);
	}
	
	public Text(String string) {
		text(string, 0, 0, 1);
	}
	
	public Text() {
		text("0", 0, 0, 1);
	}
	
	public void setString(String string) {
		mString = string;
		createText();
	}
	
	public void setTransform(float positionX, float positionY, float scale) {
		mPosition = new Vector(positionX, positionY);
		mScale = scale;
		createText();
	}
	
	public void setPosition(float positionX, float positionY) {
		mPosition = new Vector(positionX, positionY);
		createText();
	}
	
	public void setScale(float scale) {
		mScale = scale;
		createText();
	}
	
	public String getString() {
		return mString;
	}
	
	public Vector getPosition() {
		return mPosition;
	}
	
	public float getScale() {
		return mScale;
	}
	
	public void draw() {
		for (byte i = 0; i < mCharacters.length; i++)
			mCharacters[i].draw();
	}
	
	private void text(String string, float positionX, float positionY, float scale) {
		mString = string;
		mPosition = new Vector(positionX, positionY);
		mScale = scale;
		createText();
	}
	
	private void createText() {
		float textLength = 0, currentTextLength = 0;
		mCharacters = new Sprite[mString.length()];
		for (byte i = 0; i < mCharacters.length; i++) {
			mCharacters[i] = new Sprite(Font.mCharacters[mString.charAt(i) - 48]);
			textLength += mCharacters[i].getTexture().mWidth * mScale;
		}
		for (byte i = 0; i < mCharacters.length; i++) {
			mCharacters[i].setTransform(mPosition.mComponentX + currentTextLength + (mCharacters[i].getTexture().mWidth * mScale - textLength) / 2, mPosition.mComponentY, mScale, mScale);
			currentTextLength += mCharacters[i].getTexture().mWidth * mScale;
		}
	}
	
}
