package com.theNumbers.game;

import java.util.Calendar;

public class Timer {

	private Calendar mCalendar;
	
	public Timer() {
		mCalendar = Calendar.getInstance();
	}
	
	public long getTimer() {
		return Calendar.getInstance().getTime().getTime() - mCalendar.getTime().getTime();
	}
	
	public void restart() {
		mCalendar = Calendar.getInstance();
	}
	
}
