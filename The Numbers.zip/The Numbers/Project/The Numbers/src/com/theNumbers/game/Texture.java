package com.theNumbers.game;

public enum Texture {
	
	Zero((byte) 0, (short) 173, (short) 192),
	One((byte) 1, (short) 174, (short) 189),
	Two((byte) 2, (short) 173, (short) 189),
	Three((byte) 3, (short) 173, (short) 191),
	Four((byte) 4, (short) 173, (short) 191),
	Five((byte) 5, (short) 174, (short) 190),
	Six((byte) 6, (short) 173, (short) 191),
	Seven((byte) 7, (short) 173, (short) 188),
	Eight((byte) 8, (short) 174, (short) 191),
	Nine((byte) 9, (short) 173, (short) 192),
	Colon((byte) 10, (short) 83, (short) 150),
	QuestionMark((byte) 11, (short) 210, (short) 307),
	XMark((byte) 12, (short) 307, (short) 288),
	Border((byte) 13, (short) 454, (short) 124),
	Button((byte) 14, (short) 124, (short) 124),
	Heart((byte) 15, (short) 103, (short) 85),
	Medal((byte) 16, (short) 79, (short) 104),
	FreeLive((byte) 17, (short) 140, (short) 28),
	Of((byte) 18, (short) 39, (short) 26),
	In((byte) 19, (short) 29, (short) 24),
	HighScore((byte) 20, (short) 172, (short) 35),
	TapToPlay((byte) 21, (short) 836, (short) 156),
	NoLive((byte) 22, (short) 648, (short) 40),
	TotalScore((byte) 23, (short) 405, (short) 58),
	Level((byte) 24, (short) 360, (short) 104),
	Congratulations((byte) 25, (short) 921, (short) 120),
	YouWon((byte) 26, (short) 386, (short) 30),
	Ring((byte) 27, (short) 547, (short) 547),
	Line((byte) 28, (short) 1, (short) 6),
	None((byte) 29, (short) 1, (short) 1);
	
	public final byte mID;
	public final short mWidth;
	public final short mHeight;
	
	private Texture(byte id, short width, short height) {
		mID = id;
		mWidth = width;
		mHeight = height;
	}
}
