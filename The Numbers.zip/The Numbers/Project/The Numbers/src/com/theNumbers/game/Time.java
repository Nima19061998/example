package com.theNumbers.game;

import java.util.Calendar;

public class Time {

	private Calendar mCalendar;
	
	public Time(long time) {
		time(time);
	}
	
	public void setTime(long time) {
		mCalendar.setTimeInMillis(time);
	}
	
	public Time() {
		time(Calendar.getInstance().getTime().getTime());
	}
	
	public long getTime() {
		return mCalendar.getTime().getTime();
	}
	
	public byte getCounter() {
		Calendar calendar = Calendar.getInstance();
		long time = calendar.getTime().getTime() - mCalendar.getTime().getTime();
		if (time > 21600000)
			mCalendar.setTimeInMillis(Calendar.getInstance().getTime().getTime() - 21600000);
		return (byte) (time / 300000);
	}
	
	public String showTime() {
		Calendar calendar = Calendar.getInstance();
		char[] result = new char[4];
		long time = calendar.getTime().getTime() - mCalendar.getTime().getTime(); 
		byte minute = (byte) (4 - (time % 300000) / 60000);
		byte second = (byte) (59 - ((time % 300000) % 60000) / 1000);
		result[0] = (char) (minute + 48);
		result[1] = ':';
		result[2] = second < 10 ? '0' : (char) (second / 10 + 48);
		result[3] = (char) (second % 10 + 48);
		return String.valueOf(result);
	}
	
	public void loseCounter() {
		mCalendar.add(Calendar.MINUTE, 5);
	}
	
	private void time(long time) {
		mCalendar = Calendar.getInstance();
		mCalendar.setTimeInMillis(time);
	}
	
}
